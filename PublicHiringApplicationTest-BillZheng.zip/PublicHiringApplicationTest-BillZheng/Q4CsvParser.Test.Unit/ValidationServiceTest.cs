﻿using Q4CsvParser.Web.Core;
using Xunit;

namespace Q4CsvParser.Test.Unit
{
    /// <summary>
    /// This class should have content. 
    /// Feel free to use any testing framework you desire. (i.e. NUnit, XUnit, Microsoft built-in testing framework)
    /// You may also use a mocking framework (i.e. Moq, RhinoMock)
    /// 
    /// If you've never done unit testing before, don't worry about this section and look to complete some of the bonus mark tasks
    /// </summary>
    public class ValidationServiceTest
    {
        //TODO unit test the ValidationService here

        [Fact]
        public void TestIsCsvFile()
        {
            var service = new ValidationService();

            //could not figure out why Xunit.Assert is not available
            Assert.True(service.IsCsvFile("Test.CSV"));
            Assert.False(service.IsCsvFile("Test.Jpg"));
        }
    }
}
