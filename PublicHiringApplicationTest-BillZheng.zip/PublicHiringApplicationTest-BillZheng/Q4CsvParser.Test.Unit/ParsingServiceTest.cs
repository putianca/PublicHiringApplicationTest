﻿using Q4CsvParser.Web.Core;
using Xunit;
using System;

namespace Q4CsvParser.Test.Unit
{
    /// <summary>
    /// This class should have content. 
    /// Feel free to use any testing framework you desire. (i.e. NUnit, XUnit, Microsoft built-in testing framework)
    /// You may also use a mocking framework (i.e. Moq, RhinoMock)
    /// 
    /// If you've never done unit testing before, don't worry about this section and look to complete some of the bonus mark tasks
    /// </summary>
    /// 

    public class ParsingServiceTest
    {
        //TODO Unit test the ParsingService here

         //I always use XUnit for test, but I cannot download it from my home desktop
       
        [Fact]
        public void TestParseCsv1() {
            var testData = "h1, h2, h3" + Environment.NewLine + "v1, v2, v3";
            var parser = new ParsingService();

            var result = parser.ParseCsv(testData, true);
            
            Assert.True(result.HeaderRow!=null);
            Assert.True(result.Rows.Count ==1);
        }

        [Fact]
        public void TestParseCsv2()
        {
            var testData = "v1, v2, v3" + Environment.NewLine + "v1, v2, v3";
            var parser = new ParsingService();

            var result = parser.ParseCsv(testData, false);

            Assert.True(result.HeaderRow==null);
            Assert.True(result.Rows.Count ==2);
        }

    }
}
