﻿using System;
using Q4CsvParser.Contracts;
using Q4CsvParser.Domain;

namespace Q4CsvParser.Web.Core
{
    /// <summary>
    /// This file must be unit tested.
    /// </summary>
    public class ParsingService : IParsingService
    {
        /// <summary>
        /// Accepts a string with the contents of the csv file in it and should return a parsed csv file.
        /// </summary>
        /// <param name="fileContent"></param>
        /// <param name="containsHeader"></param>
        /// <returns></returns>
        public CsvTable ParseCsv(string fileContent, bool containsHeader)
        {
            //TODO fill in your logic here
            var table = new CsvTable();
            string[] lines = fileContent.Split(
                new[] { Environment.NewLine },
                    StringSplitOptions.None);
            if (lines.Length == 0) return table;
            var i = 0;
            if (containsHeader)
            {
                table.HeaderRow = new CsvRow();
                var headers = lines[0].Split(',');
                for(var j=0; j<headers.Length; j++)
                {
                    table.HeaderRow.Columns.Add(new CsvColumn(headers[j]));
                }
                i = 1;
            }
            for(;i < lines.Length; i++)
            {
                var row = new CsvRow();
                var values = lines[i].Split(',');
                for (var j = 0; j < values.Length; j++)
                {
                    row.Columns.Add(new CsvColumn(values[j]));
                }
                table.Rows.Add(row);
            }

            return table;
        }
    }
}
