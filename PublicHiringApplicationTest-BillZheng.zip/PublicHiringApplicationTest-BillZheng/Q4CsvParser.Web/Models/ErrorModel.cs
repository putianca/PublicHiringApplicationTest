﻿namespace Q4CsvParser.Web.Models
{
    public class ErrorModel
    {
        public string ErrorMessage { get; set; }
    }
}