﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Owin;
using Ninject;
using Ninject.Web.Common;
using Ninject.Web.Common.WebHost;
using Q4CsvParser.Contracts;
using Q4CsvParser.Web.Core;

namespace Q4CsvParser.Web
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {   
            //Could find why the extension method is not available
            app.UseNinjectMiddleware(CreateKernel);
        }
        public static IKernel CreateKernel()
        {
            var kernel = new StandardKernel();
            kernel.Bind<IFileService>().To<FileService>();
            kernel.Bind<IParsingService>().To<ParsingService>();
            kernel.Bind<IValidationService>().To<ValidationService>();
            kernel.Bind<ICsvFileHandler>().To<CsvFileHandler>();
            return kernel;
        }
    }
}